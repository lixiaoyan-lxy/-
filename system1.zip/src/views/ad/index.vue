<template>
    <div>积分中心</div>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>

</style>