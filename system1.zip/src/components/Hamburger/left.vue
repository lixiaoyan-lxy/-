<template>
    <div class="left"></div>
</template>
<style scoped>
.left{
    width: 15%;
    /* background: rosybrown; */
}
</style>