<template>
    <div>物流中心</div>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>

</style>